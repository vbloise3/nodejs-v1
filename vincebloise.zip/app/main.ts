/**
 * Created by vincebloise on 6/11/16.
 */
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';

import { AppModule }  from './app.module';

platformBrowserDynamic().bootstrapModule(AppModule);